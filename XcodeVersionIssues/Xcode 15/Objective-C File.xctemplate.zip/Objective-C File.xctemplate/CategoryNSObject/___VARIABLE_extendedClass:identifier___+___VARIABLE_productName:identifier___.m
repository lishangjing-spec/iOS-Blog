//___FILEHEADER___

#import "___VARIABLE_extendedClass:identifier___+___VARIABLE_productName:identifier___.h"

@implementation ___VARIABLE_extendedClass:identifier___ (___VARIABLE_productName:identifier___)

@end
